`Datasets.zip` contains all the data used in evaluations.

`ARTime for DS and Eval.zip` is an alternation of ARTime used for generating distant supervision signals and evaluation.

`trainer.py` is the script used in training the models. 

`Input.zip` contains the training and test input of our models.
* The `.txt` files (e.g., te3-test.txt) are the original inputs with IDs of time expressions.
  - They may not contain all the expressions in `Datasets.zip`. This is because ARTime cannot guarantee to present a reasonable interpretation for all annotations in the training data
* The `.json` files are the inputs and configurations of Hugging Face transformers's format. (i.e., the formats accepted by `trainer.py`.)

`Results.zip` are the running logs and main results.
* `generated_predictions.txt` is the output of our models.
* `model log.txt` is the running log of `trainer.py`.
* `evaluation log.txt` contains the evaluation results with detailed log of negative predications.
* `error analysis.xlsx` is our manual analysis of `evaluation log.txt`. 